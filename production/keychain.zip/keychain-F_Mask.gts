G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-08-24T18:36:20+02:00*
G04 #@! TF.ProjectId,keychain,6b657963-6861-4696-9e2e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-24 18:36:20*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,5.000000*%
%ADD11C,0.250000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H1*
X112000000Y-129000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,AE1*
X102212500Y-121962500D03*
X104012500Y-120612500D03*
G04 #@! TD*
M02*
